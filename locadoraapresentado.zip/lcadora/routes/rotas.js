import express from 'express';
import Cliente from '../models/cliente.js'; 
import Veiculo from '../models/veiculo.js'; 
import Funcionario from '../models/funcionario.js';
import Departamento from '../models/Departamento.js';
import OrdemDeServico from '../models/OrdemDeServico.js';

import { listarClientes, criarCliente, deletarCliente, atualizarCliente } from '../controllers/clientes.js';
import { listarFuncionarios, criarFuncionario, deletarFuncionario, atualizarFuncionario } from '../controllers/funcionarios.js';
import { listarVeiculos, criarVeiculo, deletarVeiculo, atualizarVeiculo } from '../controllers/veiculos.js';
import { listarOrdemDeServico, criarOrdemDeServico, exibirFormularioAtualizacao, atualizarOrdemDeServico, deletarOrdemDeServico } from '../controllers/ordemDeServico.js';

const router = express.Router();

router.get('/listarclientes', listarClientes);
router.post('/cadastro', criarCliente);

router.get('/atualizar/:cpf', async (req, res) => {
  const { cpf } = req.params;
  try {
    const cliente = await Cliente.findOne({ where: { clienteCPF: cpf } });
    if (!cliente) {
      return res.status(404).send('Cliente não encontrado');
    }
    res.render('atualizarCliente', { cliente });
  } catch (erro) {
    console.error(erro);
    res.status(500).send('Erro ao carregar o cliente');
  }
});

router.post('/atualizar/:cpf', atualizarCliente);

router.delete('/deletar/:cpf', async (req, res) => {
    const { cpf } = req.params;
    console.log(`Tentando deletar cliente com CPF: ${cpf}`);

    try {
        const resultado = await Cliente.destroy({ where: { clienteCPF: cpf } });

        if (resultado) {
            console.log('Cliente deletado com sucesso');
            res.redirect('/listarclientes');
        } else {
            console.log('Cliente não encontrado');
            res.status(404).send('Cliente não encontrado');
        }
    } catch (error) {
        console.error('Erro ao excluir cliente:', error);
        res.status(500).send('Erro ao excluir cliente');
    }
});

router.get('/funcionarios', (req, res) => {
  res.render('funcionarios');
});
  
router.get('/listarFuncionarios', async (req, res) => {
    try {
        const funcionarios = await Funcionario.findAll();  
        res.render('listarFuncionarios', { funcionarios });  
    } catch (error) {
        console.error('Erro ao buscar funcionários:', error);
        res.status(500).send('Erro ao carregar os funcionários');
    }
});

router.post('/funcionarios', criarFuncionario);

router.get('/atualizarfuncionario/:funcMatricula', async (req, res) => {
    const { funcMatricula } = req.params;
    try {
        const funcionario = await Funcionario.findOne({ where: { funcMatricula } });
        if (!funcionario) {
            return res.status(404).send('Funcionário não encontrado');
        }
        res.render('atualizarFuncionario', { funcionario });
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao carregar os dados do funcionário');
    }
});

router.post('/atualizarfuncionario/:funcMatricula', async (req, res) => {
    const { funcMatricula } = req.params;
    const { funcNome, funcDepto, funcSalario, funcAdmissao, funcFilho, funcSexo, funcAtivo } = req.body;

    try {
        const funcionario = await Funcionario.findOne({ where: { funcMatricula } });
        if (!funcionario) {
            return res.status(404).send('Funcionário não encontrado');
        }

        funcionario.funcNome = funcNome;
        funcionario.funcDepto = funcDepto;
        funcionario.funcSalario = funcSalario;
        funcionario.funcAdmissao = funcAdmissao;
        funcionario.funcFilho = funcFilho;
        funcionario.funcSexo = funcSexo;
        funcionario.funcAtivo = funcAtivo;

        await funcionario.save();
        res.redirect('/listarFuncionarios');
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao atualizar funcionário');
    }
});
  
router.delete('/deletarfuncionario/:funcMatricula', async (req, res) => {
    const { funcMatricula } = req.params;
    try {
        const funcionario = await Funcionario.findOne({ where: { funcMatricula } });
        if (!funcionario) {
            return res.status(404).send('Funcionário não encontrado');
        }
        const resultado = await Funcionario.destroy({ where: { funcMatricula } });
        if (resultado) {
            return res.redirect('/listarFuncionarios');
        } else {
            return res.status(404).send('Funcionário não encontrado');
        }
    } catch (erro) {
        console.error('Erro ao excluir funcionário:', erro);
        res.status(500).send('Erro ao excluir o funcionário');
    }
});

router.get('/cadveic', (req, res) => {
  res.render('cadveic');
});

router.get('/listarVeiculos', listarVeiculos);
router.post('/veiculos', criarVeiculo);

router.get('/atualizarveiculo/:veicPlaca', async (req, res) => {
    const { veicPlaca } = req.params;
    try {
        const veiculo = await Veiculo.findOne({ where: { veicPlaca: veicPlaca } });
        if (!veiculo) {
            return res.status(404).send('Veículo não encontrado');
        }
        res.render('atualizarVeiculo', { veiculo });
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao carregar o veículo');
    }
});

router.post('/atualizarveiculo/:veicPlaca', async (req, res) => {
    const { veicPlaca } = req.params;
    const { veicMarca, veicModelo, veicCor, veicAno, veicComb, veicCat, veicStatusAlocado } = req.body;

    try {
        const veiculo = await Veiculo.findOne({ where: { veicPlaca } });
        if (!veiculo) {
            return res.status(404).send('Veículo não encontrado');
        }

        veiculo.veicMarca = veicMarca;
        veiculo.veicModelo = veicModelo;
        veiculo.veicCor = veicCor;
        veiculo.veicAno = veicAno;
        veiculo.veicComb = veicComb;
        veiculo.veicCat = veicCat;
        veiculo.veicStatusAlocado = veicStatusAlocado;

        await veiculo.save();
        res.redirect('/listarVeiculos'); 
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao atualizar veículo');
    }
});

router.delete('/deletarveiculo/:veicPlaca', async (req, res) => {
    const { veicPlaca } = req.params;
    try {
        const resultado = await Veiculo.destroy({ where: { veicPlaca } });

        if (resultado) {
            return res.redirect('/listarVeiculos');
        } else {
            return res.status(404).send('Veículo não encontrado');
        }
    } catch (erro) {
        console.error('Erro ao excluir veículo:', erro);
        res.status(500).send('Erro ao excluir o veículo');
    }
});

router.get('/ordem', (req, res) => {
    res.render('ordem');
});

router.get('/listarOrdensDeServico', listarOrdemDeServico);

router.get('/atualizarOrdemDeServico/:osNum', exibirFormularioAtualizacao);

router.post('/atualizarOrdemDeServico/:osNum', atualizarOrdemDeServico);

router.post('/ordem', criarOrdemDeServico);

router.delete('/ordemDeServico/:id', deletarOrdemDeServico);

router.get('/login', (req, res) => {
    res.render('login');
});

router.get('/veiculos', (req, res) => {
    res.render('veiculos');
});

router.get('/carrossem', (req, res) => {
    res.render('carrossem');
});

router.get('/suv', (req, res) => {
    res.render('suv');
});

router.get('/locadora', (req, res) => {
    res.render('locadora');
});

router.get('/cadastro', (req, res) => {
    res.render('cadastro');
});

router.get('/eco', (req, res) => {
    res.render('eco');
});

router.get('/caminhonetes', (req, res) => {
    res.render('caminhonetes');
});

router.get('/esportivos', (req, res) => {
    res.render('esportivos');
});

export default router;
