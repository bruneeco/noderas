import { DataTypes } from 'sequelize';
import sequelize from '../db.js'; 


const Veiculo = sequelize.define('Veiculo', {
  veicPlaca: {
    type: DataTypes.STRING(7),
    allowNull: false,
    primaryKey: true, 
  },
  veicMarca: {
    type: DataTypes.STRING(15),
    allowNull: false,
  },
  veicModelo: {
    type: DataTypes.STRING(15),
    allowNull: false,
  },
  veicCor: {
    type: DataTypes.STRING(15),
    allowNull: true, 
  },
  veicAno: {
    type: DataTypes.INTEGER(4),
    allowNull: false,
  },
  veicComb: {
    type: DataTypes.STRING(1),
    allowNull: true, 
  },
  veicCat: {
    type: DataTypes.INTEGER(11),
    allowNull: true, 
  },
  veicStatusAlocado: {
    type: DataTypes.TINYINT,
    allowNull: false,
  }
}, {
  tableName: 'veiculos', 
  timestamps: false, 
});
export default Veiculo;
