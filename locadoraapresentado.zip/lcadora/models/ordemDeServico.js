import { DataTypes } from 'sequelize';
import sequelize from '../db.js'; 

import Funcionario from './funcionario.js';
import Cliente from './cliente.js';
import Veiculo from './veiculo.js';


const OrdemDeServico = sequelize.define('OrdemDeServico', {
  osNum: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
    allowNull: false
  },
  osFuncMat: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  osClienteCPF: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  osVeicPlaca: {
    type: DataTypes.STRING(7),
    allowNull: false
  },
  osDataRetirada: {
    type: DataTypes.DATEONLY,
    allowNull: false
  },
  osDataDevolucao: {
    type: DataTypes.DATEONLY,
    allowNull: true
  },
  osKMRetirada: {
    type: DataTypes.DECIMAL(8, 2),
    allowNull: false
  },
  osKMDevolucao: {
    type: DataTypes.DECIMAL(8, 2),
    allowNull: false
  },
  osStatus: {
    type: DataTypes.TINYINT(1),
    allowNull: false
  },
  osValorPgto: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true
  }
}, {
  tableName: 'ordem_de_servico',
  timestamps: false
});
OrdemDeServico.belongsTo(Funcionario, { foreignKey: 'osFuncMat' });
OrdemDeServico.belongsTo(Cliente, { foreignKey: 'osClienteCPF' });
OrdemDeServico.belongsTo(Veiculo, { foreignKey: 'osVeicPlaca' });

export default OrdemDeServico;
