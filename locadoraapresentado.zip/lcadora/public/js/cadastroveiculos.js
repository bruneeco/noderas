const formData = {
    modelo: document.querySelector('input[name="modelo"]').value,
    marca: document.querySelector('input[name="marca"]').value,
    ano: document.querySelector('input[name="ano"]').value,
    placa: document.querySelector('input[name="placa"]').value,
    cor: document.querySelector('input[name="cor"]').value,
    chassi: document.querySelector('input[name="chassi"]').value,
    preco: document.querySelector('input[name="preco"]').value,
  };
  
  fetch('/veiculos', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(formData),
  })
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error('Erro:', error));
  