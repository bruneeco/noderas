import Funcionario from '../models/funcionario.js';
import Departamento from '../models/Departamento.js';


export const listarFuncionarios = async (req, res) => {
  try {
    const funcionarios = await Funcionario.findAll();
    res.status(200).json(funcionarios);
  } catch (erro) {
    console.error("Erro ao listar funcionários:", erro);
    res.status(500).json({ erro: "Erro ao listar os funcionários. Tente novamente mais tarde." });
  }
};

export const criarFuncionario = async (req, res) => {
    const {
        funcMatricula,
        funcNome,
        funcDepto,
        funcSalario,
        funcAdmissao,
        funcFilho,
        funcSexo,
        funcAtivo,
    } = req.body;

    try {
        const funcionarioExistente = await Funcionario.findOne({
            where: { funcMatricula },
        });

        if (funcionarioExistente) {
            return res.status(400).json({
                erro: 'Já existe um funcionário com esta matrícula.',
            });
        }

        // Crie o novo funcionário
        const novoFuncionario = await Funcionario.create({
            funcMatricula,
            funcNome,
            funcDepto,
            funcSalario,
            funcAdmissao,
            funcFilho,
            funcSexo,
            funcAtivo,
        });

        res.status(201).json({
            mensagem: 'Funcionário cadastrado com sucesso!',
            funcionario: novoFuncionario,
        });
    } catch (erro) {
        console.error('Erro ao cadastrar funcionário:', erro);
        res.status(500).json({ erro: 'Erro ao cadastrar funcionário' });
    }
};

export const deletarFuncionario = async (req, res) => {
  const { funcMatricula } = req.params;

  try {
    const funcionario = await Funcionario.findOne({ where: { funcMatricula } });
    if (!funcionario) {
      return res.status(404).json({ erro: "Funcionário não encontrado." });
    }

    await funcionario.destroy();
    res.status(200).json({ mensagem: "Funcionário deletado com sucesso!" });
  } catch (erro) {
    console.error("Erro ao deletar funcionário:", erro);
    res.status(500).json({ erro: "Erro ao deletar funcionário. Tente novamente mais tarde." });
  }
};
export const atualizarFuncionario = async (req, res) => {
  const { funcMatricula } = req.params;
  const { funcNome, funcDepto, funcSalario, funcAdmissao, funcFilho, funcSexo, funcAtivo } = req.body;

  try {
    const funcionario = await Funcionario.findOne({ where: { funcMatricula } });
    if (!funcionario) {
      return res.status(404).json({ erro: "Funcionário não encontrado." });
    }

    funcionario.funcNome = funcNome || funcionario.funcNome;
    funcionario.funcDepto = funcDepto || funcionario.funcDepto;
    funcionario.funcSalario = funcSalario || funcionario.funcSalario;
    funcionario.funcAdmissao = funcAdmissao || funcionario.funcAdmissao;
    funcionario.funcFilho = funcFilho || funcionario.funcFilho;
    funcionario.funcSexo = funcSexo || funcionario.funcSexo;
    funcionario.funcAtivo = funcAtivo === undefined ? funcionario.funcAtivo : funcAtivo;

    await funcionario.save();
    res.status(200).json({ mensagem: "Funcionário atualizado com sucesso!", funcionario });
  } catch (erro) {
    console.error("Erro ao atualizar funcionário:", erro);
    res.status(500).json({ erro: "Erro ao atualizar funcionário. Tente novamente mais tarde." });
  }
};