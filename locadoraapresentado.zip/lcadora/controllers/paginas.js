const express = require('express');
const router = express.Router();

const veiculosController = require('../controllers/veiculos'); 
const funcionariosController = require('../controllers/funcionarios'); 
const clientesController = require('../controllers/clientes');


router.get('/cadveic', (req, res) => {
  res.render('cadveic');
});

router.get('/cadastro', (req, res) => {
  res.render('cadastro');
});


router.get('/listarclientes', (req, res) => {
  clientesController.listClientes()
    .then((clientes) => {
      res.render('listarclientes', { clientes });
    })
    .catch((err) => {
      console.error('Erro ao listar clientes:', err);
      res.status(500).send('Erro ao listar clientes');
    });
});

router.get('/listarFuncionarios', (req, res) => {
  funcionariosController.listFuncionarios()
    .then((funcionarios) => {
      res.render('listarFuncionarios', { funcionarios });
    })
    .catch((err) => {
      console.error('Erro ao listar funcionários:', err);
      res.status(500).send('Erro ao listar funcionários');
    });
});


router.get('/listarVeiculos', (req, res) => {
  veiculosController.listVeiculos()
    .then((veiculos) => {
      res.render('listarVeiculos', { veiculos });
    })
    .catch((err) => {
      console.error('Erro ao listar veículos:', err);
      res.status(500).send('Erro ao listar veículos');
    });
});


router.post('/clientes', clientesController.save);
router.post('/veiculos', veiculosController.save);
router.post('/funcionarios', funcionariosController.save);

module.exports = router;
