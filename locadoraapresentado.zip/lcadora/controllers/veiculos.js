import Veiculo from '../models/veiculo.js';

export const listarVeiculos = async (req, res) => {
  try {
    const veiculos = await Veiculo.findAll();
    res.render('listarVeiculos', { veiculos });
  } catch (erro) {
    console.error("Erro ao listar veículos:", erro);
    res.status(500).json({ erro: "Erro ao listar os veículos. Tente novamente mais tarde." });
  }
};

export const criarVeiculo = async (req, res) => {
  const { placa, modelo, marca, ano, cor, combustivel, categoria, statusAlocado } = req.body;

  if (!placa || !modelo || !marca || !ano || !statusAlocado) {
    return res.status(400).json({ erro: "Placa, modelo, marca, ano e status de alocação são obrigatórios." });
  }

  try {
    const veiculo = await Veiculo.create({
      veicPlaca: placa,
      veicModelo: modelo,
      veicMarca: marca,
      veicAno: ano,
      veicCor: cor || null,   
      veicComb: combustivel || null, 
      veicCat: categoria || null,  
      veicStatusAlocado: statusAlocado,
    });

    res.status(201).json({ mensagem: "Veículo criado com sucesso!", veiculo });
  } catch (erro) {
    console.error("Erro ao criar veículo:", erro);
    if (erro.name === 'SequelizeValidationError') {
      return res.status(400).json({ erro: "Erro de validação ao criar o veículo.", detalhes: erro.errors });
    }
    res.status(500).json({ erro: "Erro ao criar veículo. Tente novamente mais tarde." });
  }
};

export const deletarVeiculo = async (req, res) => {
  const { id } = req.params;
  try {
    const veiculo = await Veiculo.findOne({ where: { id } });
    if (!veiculo) {
      return res.status(404).json({ erro: "Veículo não encontrado." });
    }
    await veiculo.destroy();
    res.status(200).json({ mensagem: "Veículo deletado com sucesso!" });
  } catch (erro) {
    console.error("Erro ao deletar veículo:", erro);
    res.status(500).json({ erro: "Erro ao deletar veículo. Tente novamente mais tarde." });
  }
};

export const atualizarVeiculo = async (req, res) => {
  const { id } = req.params;
  const { placa, modelo, marca, ano, cor, chassi, preco } = req.body;

  try {
    const veiculo = await Veiculo.findOne({ where: { id } });
    if (!veiculo) {
      return res.status(404).json({ erro: "Veículo não encontrado." });
    }

    veiculo.placa = placa || veiculo.placa;
    veiculo.modelo = modelo || veiculo.modelo;
    veiculo.marca = marca || veiculo.marca;
    veiculo.ano = ano || veiculo.ano;
    veiculo.cor = cor || veiculo.cor;
    veiculo.chassi = chassi || veiculo.chassi;
    veiculo.preco = preco || veiculo.preco;

    await veiculo.save();

    res.status(200).json({ mensagem: "Veículo atualizado com sucesso!", veiculo });
  } catch (erro) {
    console.error("Erro ao atualizar veículo:", erro);
    res.status(500).json({ erro: "Erro ao atualizar veículo. Tente novamente mais tarde." });
  }
};
