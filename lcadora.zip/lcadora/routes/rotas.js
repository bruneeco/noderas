import express from 'express';
import Cliente from '../models/cliente.js'; 
import Veiculo from '../models/veiculo.js'; 
import Funcionario from '../models/funcionario.js';
import Departamento from '../models/Departamento.js';
import OrdemDeServico from '../models/OrdemDeServico.js';


import { listarClientes, criarCliente, deletarCliente, atualizarCliente } from '../controllers/clientes.js';
import { listarFuncionarios,criarFuncionario, deletarFuncionario, atualizarFuncionario } from '../controllers/funcionarios.js';
import { listarVeiculos, criarVeiculo, deletarVeiculo, atualizarVeiculo } from '../controllers/veiculos.js';
import { listarOrdemDeServico, criarOrdemDeServico, exibirFormularioAtualizacao,atualizarOrdemDeServico, deletarOrdemDeServico } from '../controllers/ordemDeServico.js';

const router = express.Router();

// Rota para listar clientes
router.get('/listarclientes', listarClientes);

// Rota para cadastrar um novo cliente
router.post('/cadastro', criarCliente);

// Rota para atualizar um cliente (GET para carregar o formulário de atualização)
router.get('/atualizar/:cpf', async (req, res) => {
  const { cpf } = req.params;
  try {
    // Buscar os dados do cliente com o CPF fornecido
    const cliente = await Cliente.findOne({ where: { clienteCPF: cpf } });
    if (!cliente) {
      return res.status(404).send('Cliente não encontrado');
    }

    // Renderizar a página de atualização com os dados do cliente
    res.render('atualizarCliente', { cliente });
  } catch (erro) {
    console.error(erro);
    res.status(500).send('Erro ao carregar o cliente');
  }
});

// Rota para atualizar um cliente (POST para enviar os dados atualizados)
router.post('/atualizar/:cpf', atualizarCliente);

// Rota para deletar cliente
router.delete('/deletar/:cpf', async (req, res) => {
    const { cpf } = req.params;
    console.log(`Tentando deletar cliente com CPF: ${cpf}`);

    try {
        const resultado = await Cliente.destroy({ where: { clienteCPF: cpf } });

        if (resultado) {
            console.log('Cliente deletado com sucesso');
            res.redirect('/listarclientes');
        } else {
            console.log('Cliente não encontrado');
            res.status(404).send('Cliente não encontrado');
        }
    } catch (error) {
        console.error('Erro ao excluir cliente:', error);
        res.status(500).send('Erro ao excluir cliente');
    }
});


// Outras rotas para Funcionários, Veículos e Ordens de Serviço (sem alterações)
router.get('/funcionarios', (req, res) => {
  res.render('funcionarios');
});
  router.get('/listarFuncionarios', async (req, res) => {
    try {
        const funcionarios = await Funcionario.findAll();  // Buscando todos os funcionários do banco
        res.render('listarFuncionarios', { funcionarios });  // Passando a variável 'funcionarios' para o EJS
    } catch (error) {
        console.error('Erro ao buscar funcionários:', error);
        res.status(500).send('Erro ao carregar os funcionários');
    }
});


// Rota para cadastrar um funcionário (POST)
router.post('/funcionarios', criarFuncionario);

// Rota GET para carregar os dados do funcionário a ser atualizado
router.get('/atualizarfuncionario/:funcMatricula', async (req, res) => {
    const { funcMatricula } = req.params;
    try {
        // Buscar os dados do funcionário pela matrícula fornecida
        const funcionario = await Funcionario.findOne({ where: { funcMatricula } });
        if (!funcionario) {
            return res.status(404).send('Funcionário não encontrado');
        }

        // Renderizar a página de atualização com os dados do funcionário
        res.render('atualizarFuncionario', { funcionario });
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao carregar os dados do funcionário');
    }
});
// Rota POST para atualizar os dados do funcionário
router.post('/atualizarfuncionario/:funcMatricula', async (req, res) => {
    const { funcMatricula } = req.params;
    const { funcNome, funcDepto, funcSalario, funcAdmissao, funcFilho, funcSexo, funcAtivo } = req.body;

    try {
        const funcionario = await Funcionario.findOne({ where: { funcMatricula } });
        if (!funcionario) {
            return res.status(404).send('Funcionário não encontrado');
        }

        // Atualizar os dados do funcionário
        funcionario.funcNome = funcNome;
        funcionario.funcDepto = funcDepto;
        funcionario.funcSalario = funcSalario;
        funcionario.funcAdmissao = funcAdmissao;
        funcionario.funcFilho = funcFilho;
        funcionario.funcSexo = funcSexo;
        funcionario.funcAtivo = funcAtivo;

        await funcionario.save();
        res.redirect('/listarFuncionarios'); // Redireciona para a listagem de funcionários

    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao atualizar funcionário');
    }
});
  
  // Rota DELETE para excluir o funcionário
  router.delete('/deletarfuncionario/:funcMatricula', async (req, res) => {
    const { funcMatricula } = req.params;
    try {
        const funcionario = await Funcionario.findOne({ where: { funcMatricula } });
        if (!funcionario) {
            return res.status(404).send('Funcionário não encontrado');
        }
        const resultado = await Funcionario.destroy({ where: { funcMatricula } });
        if (resultado) {
            return res.redirect('/listarFuncionarios');
        } else {
            return res.status(404).send('Funcionário não encontrado');
        }
    } catch (erro) {
        console.error('Erro ao excluir funcionário:', erro);
        res.status(500).send('Erro ao excluir o funcionário');
    }
});



// Rota para veículos
router.get('/cadveic', (req, res) => {
  res.render('cadveic');
});


router.get('/listarVeiculos', listarVeiculos);
router.post('/veiculos', criarVeiculo);
// Rota para atualizar veículo (GET)
router.get('/atualizarveiculo/:veicPlaca', async (req, res) => {
    const { veicPlaca } = req.params;
    try {
        // Buscar os dados do veículo com a placa fornecida
        const veiculo = await Veiculo.findOne({ where: { veicPlaca: veicPlaca } });
        if (!veiculo) {
            return res.status(404).send('Veículo não encontrado');
        }

        // Renderizar a página de atualização com os dados do veículo
        res.render('atualizarVeiculo', { veiculo });
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao carregar o veículo');
    }
});

// Rota para atualizar o veículo (POST para enviar os dados atualizados)
router.post('/atualizarveiculo/:veicPlaca', async (req, res) => {
    const { veicPlaca } = req.params;
    const { veicMarca, veicModelo, veicCor, veicAno, veicComb, veicCat, veicStatusAlocado } = req.body;

    try {
        const veiculo = await Veiculo.findOne({ where: { veicPlaca } });
        if (!veiculo) {
            return res.status(404).send('Veículo não encontrado');
        }

        // Atualizar os dados do veículo
        veiculo.veicMarca = veicMarca;
        veiculo.veicModelo = veicModelo;
        veiculo.veicCor = veicCor;
        veiculo.veicAno = veicAno;
        veiculo.veicComb = veicComb;
        veiculo.veicCat = veicCat;
        veiculo.veicStatusAlocado = veicStatusAlocado;

        await veiculo.save();
        res.redirect('/listarVeiculos'); 
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao atualizar veículo');
    }
});

router.delete('/deletarveiculo/:veicPlaca', async (req, res) => {
    const { veicPlaca } = req.params;
    try {
        // Deletar o veículo pelo número da placa
        const resultado = await Veiculo.destroy({ where: { veicPlaca } });

        if (resultado) {
            return res.redirect('/listarVeiculos');
        } else {
            return res.status(404).send('Veículo não encontrado');
        }
    } catch (erro) {
        console.error('Erro ao excluir veículo:', erro);
        res.status(500).send('Erro ao excluir o veículo');
    }
});

// Rota para renderizar a página de criação de ordem de serviço
router.get('/ordem', (req, res) => {
    res.render('ordem'); // Renderiza o formulário de criação de ordem
  });
  
  // Rota para listar todas as ordens de serviço
  router.get('/listarOrdensDeServico', listarOrdemDeServico); // Usa o controlador para buscar dados e renderizar a view
  
  // Rota para renderizar a página de atualização de uma ordem de serviço específica
// Rota para exibir o formulário de atualização
router.get('/atualizarOrdemDeServico/:osNum', exibirFormularioAtualizacao);

// Rota para atualizar a ordem de serviço
router.post('/atualizarOrdemDeServico/:osNum', atualizarOrdemDeServico);


  
  // Rota para criar uma nova ordem de serviço
  router.post('/ordem', criarOrdemDeServico);

  

  
  // Rota para deletar uma ordem de serviço pelo ID
  router.delete('/ordemDeServico/:id', deletarOrdemDeServico);
  
router.get('/login', (req, res) => {
    res.render('login');
});

router.get('/veiculos', (req, res) => {
    res.render('veiculos');
});

router.get('/carrossem', (req, res) => {
    res.render('carrossem');
});

router.get('/suv', (req, res) => {
    res.render('suv');
});

router.get('/locadora', (req, res) => {
    res.render('locadora');
});

router.get('/cadastro', (req, res) => {
    res.render('cadastro');
  });

router.get('/eco', (req, res) => {
    res.render('eco');
});

router.get('/caminhonetes', (req, res) => {
    res.render('caminhonetes');
});

router.get('/esportivos', (req, res) => {
    res.render('esportivos');
});

export default router;
