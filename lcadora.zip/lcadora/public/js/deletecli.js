function deletarCliente(cpf) {
    if (confirm('Tem certeza que deseja excluir este cliente?')) {
        fetch(`/deletar/${cpf}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            },
        })
        .then(response => {
            if (response.ok) {
                alert('Cliente excluído com sucesso!');
                window.location.reload();  
            } else {
                alert('Erro ao excluir cliente.');
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            alert('Erro ao tentar excluir cliente.');
        });
    }
}