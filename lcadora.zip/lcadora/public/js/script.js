document.getElementById('carros').onclick = function() {
    window.location.href = 'veiculos.html'; 
};
document.getElementById('cadastoveiculos').onclick = function() {
    window.location.href = 'cadastoveiculos.html'; 
};
document.getElementById('portalcliente').onclick = function() {
    window.location.href = 'cadastro.html'; 
};
document.getElementById('esportivosbt').onclick = function() {
    window.location.href = 'esportivos.html'; 
};
document.getElementById('suvbt').onclick = function() {
    window.location.href = 'suv.html'; 
};
document.getElementById('cambt').onclick = function() {
    window.location.href = 'caminhonetes.html'; 
};
document.getElementById('ecobt').onclick = function() {
    window.location.href = 'eco.html'; 
};
