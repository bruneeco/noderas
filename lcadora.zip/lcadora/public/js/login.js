document.getElementById('formLogin').addEventListener('submit', function(e) {
    e.preventDefault();
    window.location.href = 'locadora.html'; 
});