document.getElementById('cadastroForm').addEventListener('submit', function(event) {
    event.preventDefault(); 
  
 
    const clienteCPF = document.getElementById('clienteCPF').value;
    const clienteNome = document.getElementById('clienteNome').value;
    const clienteEnde = document.getElementById('clienteEnde').value;
    const clienteTel = document.getElementById('clienteTel').value;
    const clienteCidade = document.getElementById('clienteCidade').value;
    const clienteDataNasc = document.getElementById('clienteDataNasc').value;
    const clienteCNH = document.getElementById('clienteCNH').value;
    const clienteCNHCat = document.getElementById('clienteCNHCat').value;
  
    fetch('/cadastro', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        clienteCPF,
        clienteNome,
        clienteEnde,
        clienteTel,
        clienteCidade,
        clienteDataNasc,
        clienteCNH,
        clienteCNHCat
      })
    })
    .then(response => response.json())
    .then(data => {
      if (data.mensagem) {
        alert(data.mensagem); 
      } else {
        alert(data.erro); 
      }
    })
    .catch(error => {
      console.error('Erro ao enviar os dados:', error);
      alert('Ocorreu um erro ao enviar os dados. Tente novamente mais tarde.');
    });
  });
  
   