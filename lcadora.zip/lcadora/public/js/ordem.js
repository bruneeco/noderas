document.getElementById('editBtn').addEventListener('click', function() {
    document.getElementById('alertMessage').textContent = 'Dados só podem ser alterados até três dias antes da retirada do veículo.';
});