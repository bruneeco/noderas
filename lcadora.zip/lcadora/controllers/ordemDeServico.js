import OrdemDeServico from '../models/OrdemDeServico.js';

export const listarOrdemDeServico = async (req, res) => {
  try {
    const ordensDeServico = await OrdemDeServico.findAll();
    res.render('listarOrdensDeServico', { ordensDeServico });
  } catch (erro) {
    console.error("Erro ao listar ordens de serviço:", erro);
    res.status(500).json({ erro: "Erro ao listar as ordens de serviço. Tente novamente mais tarde." });
  }
};

export const criarOrdemDeServico = async (req, res) => {
  const {
    osFuncMat,
    osClienteCPF,
    osVeicPlaca,
    osDataRetirada,
    osDataDevolucao,
    osKMRetirada,
    osKMDevolucao,
    osStatus,
    osValorPgto
  } = req.body;

  try {
    const novaOrdem = await OrdemDeServico.create({
      osFuncMat,
      osClienteCPF,
      osVeicPlaca,
      osDataRetirada,
      osDataDevolucao,
      osKMRetirada,
      osKMDevolucao,
      osStatus,
      osValorPgto
    });

    res.status(201).json({ mensagem: 'Ordem de serviço criada com sucesso!', ordemDeServico: novaOrdem });
  } catch (erro) {
    console.error('Erro ao criar ordem de serviço:', erro);
    res.status(500).json({ erro: 'Erro ao criar ordem de serviço' });
  }
};

export const exibirFormularioAtualizacao = async (req, res) => {
  const { osNum } = req.params;

  try {
    const ordem = await OrdemDeServico.findOne({
      where: { osNum }
    });

    if (!ordem) {
      return res.status(404).json({ erro: "Ordem de serviço não encontrada para o número fornecido." });
    }

    res.render('atualizarOrdemDeServico', { ordem });

  } catch (erro) {
    console.error("Erro ao buscar ordem de serviço:", erro);
    res.status(500).json({ erro: "Erro ao buscar dados da ordem de serviço." });
  }
};

export const atualizarOrdemDeServico = async (req, res) => {
  const { osNum } = req.params;
  const {
    osFuncMat,
    osClienteCPF,
    osVeicPlaca,
    osDataRetirada,
    osDataDevolucao,
    osKMRetirada,
    osKMDevolucao,
    osStatus,
    osValorPgto
  } = req.body;

  try {
    const ordemDeServico = await OrdemDeServico.findOne({ where: { osNum } });

    if (!ordemDeServico) {
      return res.status(404).json({ erro: "Ordem de serviço não encontrada para o número fornecido." });
    }

    await ordemDeServico.update({
      osFuncMat: osFuncMat || ordemDeServico.osFuncMat,
      osClienteCPF: osClienteCPF || ordemDeServico.osClienteCPF,
      osVeicPlaca: osVeicPlaca || ordemDeServico.osVeicPlaca,
      osDataRetirada: osDataRetirada || ordemDeServico.osDataRetirada,
      osDataDevolucao: osDataDevolucao || ordemDeServico.osDataDevolucao,
      osKMRetirada: osKMRetirada || ordemDeServico.osKMRetirada,
      osKMDevolucao: osKMDevolucao || ordemDeServico.osKMDevolucao,
      osStatus: osStatus || ordemDeServico.osStatus,
      osValorPgto: osValorPgto || ordemDeServico.osValorPgto
    });

    res.status(200).json({ mensagem: "Ordem de serviço atualizada com sucesso!", ordemDeServico });
  } catch (erro) {
    console.error("Erro ao atualizar ordem de serviço:", erro);
    res.status(500).json({ erro: "Erro ao atualizar ordem de serviço. Tente novamente mais tarde." });
  }
};

export const deletarOrdemDeServico = async (req, res) => {
  const { osNum } = req.params;

  try {
    const ordemDeServico = await OrdemDeServico.findOne({ where: { osNum } });

    if (!ordemDeServico) {
      return res.status(404).json({ erro: "Ordem de serviço não encontrada para o número fornecido." });
    }

    await ordemDeServico.destroy();

    res.status(200).json({ mensagem: "Ordem de serviço excluída com sucesso!" });
  } catch (erro) {
    console.error("Erro ao excluir ordem de serviço:", erro);
    res.status(500).json({ erro: "Erro ao excluir ordem de serviço. Tente novamente mais tarde." });
  }
};
