import Cliente from '../models/cliente.js';

export const listarClientes = async (req, res) => {
  try {
    const clientes = await Cliente.findAll();
    res.render('listarclientes', { clientes });
  } catch (erro) {
    console.error("Erro ao listar clientes:", erro);
    res.status(500).json({ erro: "Erro ao listar os clientes. Tente novamente mais tarde." });
  }
};

export const criarCliente = async (req, res) => {
  const { clienteCPF, clienteNome, clienteEnde, clienteTel, clienteCidade, clienteDataNasc, clienteCNH, clienteCNHCat } = req.body;

  try {
    const novoCliente = await Cliente.create({
      clienteCPF,
      clienteNome,
      clienteEnde,
      clienteTel,
      clienteCidade,
      clienteDataNasc,
      clienteCNH,
      clienteCNHCat
    });

    res.status(201).json({ mensagem: 'Cliente cadastrado com sucesso!', cliente: novoCliente });
  } catch (erro) {
    console.error('Erro ao cadastrar cliente:', erro);
    res.status(500).json({ erro: 'Erro ao cadastrar cliente' });
  }
};

export const deletarCliente = async (req, res) => {
  const { cpf } = req.params;

  try {
    const cliente = await Cliente.findOne({ where: { clienteCPF: cpf } });

    if (!cliente) {
      return res.status(404).send('Cliente não encontrado');
    }

    await cliente.destroy();

    res.redirect('/listarclientes');
  } catch (err) {
    console.error(err);
    res.status(500).send('Erro ao excluir cliente');
  }
};

export const atualizarCliente = async (req, res) => {
  const { cpf } = req.params;
  const { clienteNome, clienteEnde, clienteTel, clienteCidade, clienteDataNasc, clienteCNH, clienteCNHCat } = req.body;

  try {
    const cliente = await Cliente.findOne({ where: { clienteCPF: cpf } });

    if (!cliente) {
      return res.status(404).json({ erro: "Cliente não encontrado." });
    }

    await cliente.update({
      clienteNome: clienteNome || cliente.clienteNome,
      clienteEnde: clienteEnde || cliente.clienteEnde,
      clienteTel: clienteTel || cliente.clienteTel,
      clienteCidade: clienteCidade || cliente.clienteCidade,
      clienteDataNasc: clienteDataNasc || cliente.clienteDataNasc,
      clienteCNH: clienteCNH || cliente.clienteCNH,
      clienteCNHCat: clienteCNHCat || cliente.clienteCNHCat,
    });

    res.status(200).json({ mensagem: "Cliente atualizado com sucesso!", cliente });
  } catch (erro) {
    console.error("Erro ao atualizar cliente:", erro);
    res.status(500).json({ erro: "Erro ao atualizar cliente. Tente novamente mais tarde." });
  }
};
