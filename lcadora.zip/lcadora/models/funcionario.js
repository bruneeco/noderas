import { DataTypes } from 'sequelize';
import sequelize from '../db.js';

const Funcionario = sequelize.define('Funcionario', {
  funcMatricula: {
    type: DataTypes.INTEGER,
    primaryKey: true,
  },
  funcNome: {
    type: DataTypes.STRING(40),
    allowNull: false,
    field: 'funcNome',
  },
  funcDepto: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'funcDepto',
  },
  funcSalario: {
    type: DataTypes.DECIMAL(8, 2),
    allowNull: false,
    field: 'funcSalario',
  },
  funcAdmissao: {
    type: DataTypes.DATE,
    allowNull: false,
    field: 'funcAdmissao',
  },
  funcFilho: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'funcFilho',
  },
  funcSexo: {
    type: DataTypes.STRING(1),
    allowNull: false,
    field: 'funcSexo',
  },
  funcAtivo: {
    type: DataTypes.TINYINT(1),
    allowNull: false,
    field: 'funcAtivo',
  },
}, {
  tableName: 'funcionarios',
  timestamps: false,
});

export default Funcionario;
