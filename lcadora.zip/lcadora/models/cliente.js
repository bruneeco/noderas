import { DataTypes } from 'sequelize';
import sequelize from '../db.js';

const Cliente = sequelize.define('Cliente', {
  clienteCPF: {
    type: DataTypes.INTEGER(9),
    primaryKey: true,
    unique: true,
    allowNull: false,
  },
  clienteNome: {
    type: DataTypes.STRING(40),
    allowNull: false,
    field: 'clienteNome',
  },
  clienteEnde: {
    type: DataTypes.STRING(60),
    allowNull: false,
    field: 'clienteEnde',
  },
  clienteTel: {
    type: DataTypes.STRING(15),
    allowNull: false,
    field: 'clienteTel',
  },
  clienteCidade: {
    type: DataTypes.STRING(60),
    allowNull: false,
    field: 'clienteCidade',
  },
  clienteDataNasc: {
    type: DataTypes.DATE,
    allowNull: false,
    field: 'clienteDataNasc',
  },
  clienteCNH: {
    type: DataTypes.BIGINT(11),
    allowNull: false,
    field: 'clienteCNH',
  },
  clienteCNHCat: {
    type: DataTypes.STRING(2),
    allowNull: false,
    field: 'clienteCNHCat',
  },
}, {
  tableName: 'clientes',
  timestamps: false,
});

export default Cliente;
