import { DataTypes } from 'sequelize';
import sequelize from '../db.js';

const Departamento = sequelize.define(
  'Departamento',
  {
    deptoCod: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      allowNull: false,
      field: 'deptoCod',
    },
    deptoNome: {
      type: DataTypes.STRING(20),
      allowNull: false,
      field: 'deptoNome',
    },
  },
  {
    tableName: 'departamento',
    timestamps: false,
  }
);

export default Departamento;
